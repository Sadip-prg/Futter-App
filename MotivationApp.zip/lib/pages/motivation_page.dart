import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:motivationapp/data/quotes_data.dart';
import 'package:motivationapp/widgets/motivation_card.dart';

class MotivationPage extends StatefulWidget {
  @override
  _MotivationPageState createState() => _MotivationPageState();
}

class _MotivationPageState extends State<MotivationPage> {
  int _currentIndex = 0;

  // List of all quotes
  final List<Quote> _quotes = quotes;

  // Favorites list
  List<Quote> _favorites = [];

  // Load favorites from SharedPreferences
  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final favoritesJson = prefs.getString('favorites');
    if (favoritesJson != null) {
      try {
        final List decoded = jsonDecode(favoritesJson);
        setState(() {
          _favorites = decoded
              .map((item) => Quote(item['quote'], item['author']))
              .toList();
        });
      } catch (e) {
        print("Error loading favorites: $e");
      }
    }
  }

  // Save favorites to SharedPreferences
  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final favoritesJson = jsonEncode(
      _favorites.map((q) => {'quote': q.text, 'author': q.author}).toList(),
    );
    await prefs.setString('favorites', favoritesJson);
  }
  
  void _setRandomQuote() {
    final random = Random();
    _currentIndex = random.nextInt(_quotes.length);
  }


  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _setRandomQuote();
  }

  void _showNextQuote() {
    setState(() {
      _currentIndex = (_currentIndex + 1) % _quotes.length;
    });
  }

  void _showPreviousQuote() {
    setState(() {
      _currentIndex = (_currentIndex - 1 + _quotes.length) % _quotes.length;
    });
  }

  void _addToFavorites(Quote quote) {
    if (!_favorites.any((q) => q.text == quote.text && q.author == quote.author)) {
      setState(() {
        _favorites.add(quote);
      });
      _saveFavorites();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Added to favorites")),
      );
    }
  }

  void _openFavoritesPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FavoritesPage(
          favorites: _favorites,
          onFavoritesUpdated: _loadFavorites,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentQuote = _quotes[_currentIndex];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[200]!,
        title: Row(
          children: [
            Image.asset(
              'assets/Bossysmile.png',
              height: 40,
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  "Daily Motivation",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                Text(
                  "Believe in yourself, you're amazing",
                  style: TextStyle(
                    fontSize: 12,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite, color: Colors.red),
            onPressed: _openFavoritesPage,
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          const Text(
            "Find your favorite motivational quote",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
          Expanded(
            child: Center(
              child: MotivationCard(
                quote: currentQuote.text,
                author: currentQuote.author,
                onNext: _showNextQuote,
                onPrevious: _showPreviousQuote,
                onFavorite: () => _addToFavorites(currentQuote),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class FavoritesPage extends StatefulWidget {
  final List<Quote> favorites;
  final VoidCallback onFavoritesUpdated;

  const FavoritesPage({required this.favorites, required this.onFavoritesUpdated, super.key});

  @override
  _FavoritesPageState createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {

  void _deleteFavorite(int index) async {
    setState(() {
      widget.favorites.removeAt(index);
    });
    final prefs = await SharedPreferences.getInstance();
    final favoritesJson = jsonEncode(
      widget.favorites.map((q) => {'quote': q.text, 'author': q.author}).toList(),
    );
    await prefs.setString('favorites', favoritesJson);
    widget.onFavoritesUpdated();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Favorites"),
        backgroundColor: Colors.blue[200]!,
      ),
      body: widget.favorites.isEmpty
          ? const Center(child: Text("No favorites yet."))
          : ListView.builder(
              itemCount: widget.favorites.length,
              itemBuilder: (context, index) {
                final fav = widget.favorites[index];
                return ListTile(
                  title: Text(fav.text),
                  subtitle: Text(fav.author.isEmpty ? "Unknown" : fav.author),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _deleteFavorite(index),
                  ),
                );
              },
            ),
    );
  }
}