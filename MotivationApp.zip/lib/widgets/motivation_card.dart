import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

class MotivationCard extends StatelessWidget {
  final String quote;
  final String author;
  final VoidCallback onNext;
  final VoidCallback onPrevious;
  final VoidCallback onFavorite;

  const MotivationCard({
    super.key,
    required this.quote,
    required this.author,
    required this.onNext,
    required this.onPrevious,
    required this.onFavorite,
  });

  void _shareQuote() {
    Share.share('"$quote" - $author');
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 5,
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              quote,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              "- $author",
              style: const TextStyle(
                fontSize: 16,
                fontStyle: FontStyle.italic,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  onPressed: onPrevious,
                  child: const Text("Previous"),
                ),
                ElevatedButton(
                  onPressed: onNext,
                  child: const Text("Next"),
                ),
                IconButton(
                  icon: const Icon(Icons.favorite_border, color: Colors.red),
                  onPressed: onFavorite,
                ),
                IconButton(
                  icon: const Icon(Icons.share, color: Colors.blue),
                  onPressed: _shareQuote,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}